#! /bin/sh
# This is a generated file.
srcdir=D:/Development/op3d_active/pcre-8.33
pcretest=D:/Development/op3d_active/pcre-8.33/msvc/DEBUG/pcretest.exe
source D:/Development/op3d_active/pcre-8.33/RunTest
if test "$?" != "0"; then exit 1; fi
# End
